package com.example;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class AudioService {

    @Autowired
    AudioRepository audioRepository;
    WordController wordController;


    public List<AudioClass> getAllWords()
    {
       return audioRepository.findAll();
    }

    public List<AudioClass> getAllMissingWord()
    {
        int j=0;
        List <AudioClass>list=audioRepository.findAll();
        List newlist=new ArrayList<String>();
        for(AudioClass audio:list)
        {
            newlist.add(audio.getWord_name());

        }

        File f1=new File("D://Gais//Audio//");
        String[]listOfFiles1 = f1.list();
        String[] str=new String[10];
        List l2=new ArrayList();
       // List l1=new ArrayList();
        for(int i=0;i<listOfFiles1.length;i++)
        {
            str[i]=listOfFiles1[i].replace(".wav"," ");

          System.out.println(str[i]);
        }
        Iterator l=newlist.iterator();
        {

            while(l.hasNext())
            {

                if(l.equals(str[j]))
                {
                    l2.add(newlist);

                }
                j++;
                System.out.println(l2);
            }


        }

        return null;
    }



}
