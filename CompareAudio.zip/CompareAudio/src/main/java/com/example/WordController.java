package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class WordController {

    @Autowired
    AudioService audioService;

    @GetMapping("/getallwords")
    public List<AudioClass> getAllWords()
    {
        return audioService.getAllWords();
    }

    @GetMapping("/getmissingword")
    public List<AudioClass> getAllMissingWord()
    {

        return audioService.getAllMissingWord();
    }

}
